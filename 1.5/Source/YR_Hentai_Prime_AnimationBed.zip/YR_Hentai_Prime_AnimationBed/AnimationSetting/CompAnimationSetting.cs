﻿using System.Collections.Generic;
using UnityEngine;
using Verse;

namespace YR_Hentai_Prime_AnimationBed
{
    public class CompAnimationSetting : CompBaseOfAnimationBed
    {
        public CompProperties_AnimationSetting Props => (CompProperties_AnimationSetting)props;

        public List<BedAnimationSettingAndTick> bedAnimationSettingAndTicks = new List<BedAnimationSettingAndTick>();
        public List<PortraitIngredient> portraitIngredients = new List<PortraitIngredient>();

        public bool needMakeGraphics = true;

    }

    public class PortraitIngredient
    {
        public Material material;
        public Texture2D maskTexture;
        public Vector3 offset;
        public float angle;
        public Vector2 drawSize;
        public Vector3 cameraOffset;
        public float cameraZoom;
        public PortraitSetting portraitSetting;

        public Vector3 testOffset;
        public float testAngle;
        public Vector2 testDrawSize;
        public Vector3 testCameraOffset;
        public float testCameraZoom;

        public bool openTestGizmo;
    }

    public class BedAnimationSettingAndTick
    {
        public List<BedAnimationSetting> bedAnimationSettings = new List<BedAnimationSetting>(10);

        public int durationTick;
        public int currentTick;
        public bool autoDurationTicksSetting = false;
        public BedAnimationDef parentBedAnimationDef;
        public bool openTestGizmo = false;
    }

    public class BedAnimationSetting
    {
        public Condition condition;
        public GraphicData graphicData;
        public string maskPathForPortrait;
        public Graphic graphic;
        public int tick;
        public Vector3 offset;
        public Rot4? rotation;
        public SoundDef soundDef;
        public int angle;
        public bool setPawnColor;
        public BedAnimationDef parentBedAnimationDef;

        public Vector3 testOffset = Vector3.zero;
        public Vector2 testDrawSize = Vector2.zero;

        public BedAnimationSetting Copy()
        {
            var copied = (BedAnimationSetting)this.MemberwiseClone();
            copied.graphic = this.graphicData.Graphic ?? new Graphic();
            return copied;
        }
    }
}
