﻿using RimWorld;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;

namespace YR_Hentai_Prime_AnimationBed
{
    public static class BedAnimationUtility
    {
        public static void DrawBedAnimation(Building_AnimationBed building_AnimationBed)
        {
            Vector3 bedBasePos = building_AnimationBed.DrawPos;

            foreach (var bedAnimationSettingAndTick in building_AnimationBed.AnimationSettingComp.bedAnimationSettingAndTicks)
            {
                int currentTick = bedAnimationSettingAndTick.currentTick;

                var closestSetting = bedAnimationSettingAndTick.bedAnimationSettings
                    .Where(b => b.tick <= currentTick)
                    .OrderByDescending(b => b.tick)
                    .FirstOrDefault()
                    ?? bedAnimationSettingAndTick.bedAnimationSettings
                    .OrderByDescending(x => x.tick)
                    .FirstOrDefault();

                if (closestSetting == null || (!bedAnimationSettingAndTick.autoDurationTicksSetting && currentTick > bedAnimationSettingAndTick.durationTick))
                    continue;

                Vector3 pos = CalculatePos(building_AnimationBed, bedBasePos, bedAnimationSettingAndTick, closestSetting);
                closestSetting.graphic?.Draw(pos, Rot4.North, building_AnimationBed.HeldPawn);
            }

            //foreach (var portraitIngredient in building_AnimationBed.AnimationSettingComp.portraitIngredients)
            //{
            //    DrawPortrait(building_AnimationBed, portraitIngredient);
            //}
        }
        private static void DrawPortrait(Building_AnimationBed building_AnimationBed, PortraitIngredient portraitIngredient)
        {

            if (building_AnimationBed.HeldPawn == null)
            {
                TestLog.Error("HeldPawn is null.");
                return;
            }

            Vector3 drawPos = building_AnimationBed.DrawPos + portraitIngredient.offset + portraitIngredient.testOffset;
            Vector3 drawSize = new Vector3(portraitIngredient.drawSize.x + portraitIngredient.testDrawSize.x, 1, portraitIngredient.drawSize.y + portraitIngredient.testDrawSize.y);
            Matrix4x4 matrix = Matrix4x4.TRS(drawPos, Quaternion.AngleAxis(portraitIngredient.angle + portraitIngredient.testAngle, Vector3.up), drawSize);

            var portraitSetting = portraitIngredient.portraitSetting;
            var cameraOffset = portraitIngredient.cameraOffset + portraitIngredient.testCameraOffset;
            if (portraitSetting.animationSynchro)
            {
                PawnRenderNode renderNode = building_AnimationBed.HeldPawn.Drawer?.renderer?.renderTree?.rootNode?.children
                    .FirstOrDefault(n => n?.Props?.tagDef == portraitSetting.pawnRenderNodeTagDef);

                if (renderNode != null)
                {
                    Vector3 offset = renderNode.Worker.OffsetFor(renderNode, building_AnimationBed.HeldPawnDrawParms, out var pivot);
                    offset -= pivot;
                    cameraOffset += offset * -1;
                }
            }

            var cameraZoom = portraitIngredient.cameraZoom + portraitIngredient.testCameraZoom;

            portraitIngredient.material.mainTexture = PortraitsCache.Get(building_AnimationBed.HeldPawn, new Vector2(256, 256), portraitSetting.rotation, cameraOffset, cameraZoom, portraitSetting.renderClothes, portraitSetting.renderHeadgear, stylingStation: false, healthStateOverride: PawnHealthState.Mobile);

            if (portraitIngredient.material.mainTexture == null)
            {
                TestLog.Error("portraitRenderTexture is null.");
                return;
            }

            GenDraw.DrawMeshNowOrLater(MeshPool.plane20, matrix, portraitIngredient.material, PawnRenderFlags.None.FlagSet(PawnRenderFlags.DrawNow));
        }



        private static Vector3 CalculatePos(Building_AnimationBed building_AnimationBed, Vector3 bedBasePos, BedAnimationSettingAndTick bedAnimationSettingAndTick, BedAnimationSetting closestSetting)
        {
            var pawn = building_AnimationBed.HeldPawn;
            if (pawn == null)
            {
                Log.Error("HeldPawn is null.");
                return bedBasePos;
            }

            Vector3 pos = new Vector3(bedBasePos.x, pawn.DrawPos.y, bedBasePos.z) + closestSetting.offset;

            if (bedAnimationSettingAndTick.parentBedAnimationDef.animationSynchro && bedAnimationSettingAndTick.parentBedAnimationDef.pawnRenderNodeTagDef != null)
            {
                PawnRenderNode renderNode = pawn.Drawer.renderer.renderTree.rootNode.children
                    .FirstOrDefault(n => n?.Props?.tagDef == bedAnimationSettingAndTick.parentBedAnimationDef.pawnRenderNodeTagDef);

                if (renderNode != null)
                {
                    Vector3 offset = renderNode.Worker.OffsetFor(renderNode, building_AnimationBed.HeldPawnDrawParms, out var pivot);
                    offset -= pivot;
                    pos += offset;

                    if (bedAnimationSettingAndTick.parentBedAnimationDef.logCurrentOffset)
                    {
                        Log.Error($"pawnRenderNodeTagDef offset : {offset.x:F5}, {offset.y:F5}, {offset.z:F5}");
                        Log.Error($"pawnRenderNodeTagDef pivot : {pivot.x:F5}, {pivot.y:F5}, {pivot.z:F5}");
                    }
                }
            }
            else if (bedAnimationSettingAndTick.parentBedAnimationDef.animationSynchrotoDummyForJoyAnimation && building_AnimationBed.dummyForJoyIsActive && building_AnimationBed.dummyForJoyPawn != null)
            {
                var dummyPawn = building_AnimationBed.dummyForJoyPawn;
                PawnRenderNode renderNode = dummyPawn.Drawer.renderer.renderTree.rootNode.children
                    .FirstOrDefault(n => n?.Props?.tagDef == bedAnimationSettingAndTick.parentBedAnimationDef.pawnRenderNodeTagDef);

                if (renderNode != null)
                {
                    Vector3 offset = renderNode.Worker.OffsetFor(renderNode, building_AnimationBed.HeldPawnDrawParms, out var pivot);
                    offset -= pivot;
                    pos += offset;

                    if (bedAnimationSettingAndTick.parentBedAnimationDef.logCurrentOffset)
                    {
                        Log.Error($"pawnRenderNodeTagDef offset : {offset.x:F5}, {offset.y:F5}, {offset.z:F5}");
                        Log.Error($"pawnRenderNodeTagDef pivot : {pivot.x:F5}, {pivot.y:F5}, {pivot.z:F5}");
                    }
                }
            }

            pos += closestSetting.testOffset;
            return pos;
        }

        public static bool MakeBedAnimation(Building_AnimationBed building_AnimationBed)
        {
            Pawn heldPawn = building_AnimationBed.HeldPawn;

            if (building_AnimationBed.AnimationSettingComp == null || !building_AnimationBed.AnimationSettingComp.needMakeGraphics)
                return false;

            if (heldPawn == null || heldPawn.Drawer?.renderer?.renderTree.rootNode == null)
            {
                TestLog.Error("can't make Graphic. HeldPawn is invalid.");
                return false;
            }

            TestLog.Error($"{heldPawn.LabelShort} : MakeBedAnimation Start");
            building_AnimationBed.AnimationSettingComp.needMakeGraphics = false; // 필요성 초기화
            building_AnimationBed.AnimationSettingComp.bedAnimationSettingAndTicks = new List<BedAnimationSettingAndTick>();

            var props = building_AnimationBed.AnimationSettingComp.Props;
            var pawnAnimationDef = GetPawnAnimationDef(building_AnimationBed);
            heldPawn.Drawer.renderer.SetAnimation(pawnAnimationDef);

            TestLog.Error("+++Check bedAnimationList+++");
            foreach (var bedAnimation in props.bedAnimationList)
            {
                BedAnimationDef bedAnimationDef = bedAnimation.bedAnimationDef;

                foreach (var conditionBedAnimationDef in bedAnimation.conditionBedAnimationDefs)
                {
                    void action() => bedAnimationDef = conditionBedAnimationDef.bedAnimationDef;

                    if (Condition.ExecuteActionIfConditionMatches(heldPawn, building_AnimationBed, conditionBedAnimationDef.condition, action))
                    {
                        break;
                    }
                }

                TestLog.Error($"=={bedAnimationDef.defName}==");
                TestLog.Error("++MakeBedAnimationSettingAndTick Start++");

                var result = MakeBedAnimationSettingAndTick(building_AnimationBed, bedAnimationDef, pawnAnimationDef);
                building_AnimationBed.AnimationSettingComp.bedAnimationSettingAndTicks.Add(result);

                TestLog.Error("++MakeBedAnimationSettingAndTick Finish++");
            }

            TestLog.Error("+++Finish Check bedAnimationList+++");

            // 포트레잇
            TestLog.Error("=============================");
            //MakePortrait(building_AnimationBed);

            return true;
        }

        private static void MakePortrait(Building_AnimationBed building_AnimationBed)
        {
            building_AnimationBed.AnimationSettingComp.portraitIngredients = new List<PortraitIngredient>();
            foreach (var pawnPortraitSetting in building_AnimationBed.AnimationSettingComp.Props.pawnPortraitSettings)
            {
                var portraitSetting = pawnPortraitSetting.portraitSetting;

                foreach (var conditionPortraitSetting in pawnPortraitSetting.conditonPortraitSettings)
                {
                    void action() => portraitSetting = conditionPortraitSetting.portraitSetting;

                    if (Condition.ExecuteActionIfConditionMatches(building_AnimationBed.HeldPawn, building_AnimationBed, conditionPortraitSetting.condition, action))
                    {
                        break;
                    }
                }

                if (!portraitSetting.draw)
                {
                    continue;
                }

                PortraitIngredient portraitIngredient = new PortraitIngredient
                {
                    drawSize = portraitSetting.drawSize,
                    angle = portraitSetting.angle,
                    offset = portraitSetting.offset,
                    //maskTexture = ContentFinder<Texture2D>.Get(portraitSetting.maskPath),
                    cameraOffset = portraitSetting.cameraOffset,
                    cameraZoom = portraitSetting.cameraZoom,
                    portraitSetting = portraitSetting,
                    material = CreateMaterial(portraitSetting, building_AnimationBed.HeldPawn)
                };

                building_AnimationBed.AnimationSettingComp.portraitIngredients.Add(portraitIngredient);
            }
        }

        private static Material CreateMaterial(PortraitSetting portraitSetting, Pawn pawn)
        {
            Material material = new Material(ShaderTypeDefOf.CutoutComplex.Shader);
            material.SetTexture(ShaderPropertyIDs.MaskTex, ContentFinder<Texture2D>.Get(portraitSetting.maskPath));
            material.SetColor(ShaderPropertyIDs.ColorTwo, new Color32());

            return material;
        }

        public static BedAnimationSettingAndTick MakeBedAnimationSettingAndTick(Building_AnimationBed building_AnimationBed, BedAnimationDef bedAnimationDef, AnimationDef pawnAnimationDef)
        {
            var bedAnimationSettings = new List<BedAnimationSetting>(10);

            var bedAnimationSettingAndTick = new BedAnimationSettingAndTick
            {
                autoDurationTicksSetting = bedAnimationDef.autoDurationTicksSetting,
                parentBedAnimationDef = bedAnimationDef,
                bedAnimationSettings = bedAnimationSettings
            };

            TestLog.Error("+Check bedAnimationSetting+");

            foreach (var bedAnimationSetting in bedAnimationDef.bedAnimationSettings)
            {
                void action()
                {
                    var settingCopy = bedAnimationSetting.Copy();
                    settingCopy.parentBedAnimationDef = bedAnimationDef;
                    settingCopy.setPawnColor = bedAnimationDef.setPawnColor;
                    settingCopy.graphic = null;

                    settingCopy.graphic = bedAnimationDef.isPawnTextureReplace
                        ? GetGraphic(building_AnimationBed.HeldPawn, bedAnimationDef.pawnRenderNodeTagDef, settingCopy)
                        : settingCopy.graphicData.Graphic;

                    if (settingCopy.graphic == null)
                    {
                        TestLog.Error("settingCopy Skip");
                    }
                    else
                    {
                        bedAnimationSettings.Add(settingCopy);
                    }
                }

                if (Condition.ExecuteActionIfConditionMatches(building_AnimationBed.HeldPawn, building_AnimationBed, bedAnimationSetting.condition, action))
                {
                    break;
                }
            }

            TestLog.Error("+Finish Check bedAnimationSetting+");

            if (bedAnimationSettings.Count != 0)
            {
                bedAnimationSettingAndTick.durationTick = bedAnimationDef.autoDurationTicksSetting
                    ? pawnAnimationDef.durationTicks
                    : bedAnimationDef.durationTicks != 0 && bedAnimationDef.durationTicks >= bedAnimationSettings.Max(x => x.tick)
                        ? bedAnimationDef.durationTicks
                        : bedAnimationSettings.Max(x => x.tick);
            }

            return bedAnimationSettingAndTick;
        }

        private static Graphic GetGraphic(Pawn pawn, PawnRenderNodeTagDef tagDef, BedAnimationSetting bedAnimationSetting)
        {
            return tagDef == PawnRenderNodeTagDefOf.Body
                ? GraphicForBody(pawn, bedAnimationSetting)
                : tagDef == PawnRenderNodeTagDefOf.Head
                    ? GraphicForHead(pawn, bedAnimationSetting)
                    : bedAnimationSetting.graphicData.Graphic;
        }

        private static AnimationDef GetPawnAnimationDef(Building_AnimationBed building_AnimationBed)
        {
            var pawnAnimationDef = building_AnimationBed.AnimationSettingComp.Props.pawnAnimationSetting.pawnAnimationDef;

            foreach (var conditonPawnAnimation in building_AnimationBed.AnimationSettingComp.Props.pawnAnimationSetting.conditonPawnAnimations)
            {
                void action() => pawnAnimationDef = conditonPawnAnimation.pawnAnimationDef;

                if (Condition.ExecuteActionIfConditionMatches(building_AnimationBed.HeldPawn, building_AnimationBed, conditonPawnAnimation.condition, action))
                {
                    break;
                }
            }

            return pawnAnimationDef;
        }

        public static Graphic GraphicForHead(Pawn pawn, BedAnimationSetting bedAnimationSetting)
        {
            if (!pawn.health.hediffSet.HasHead)
            {
                return null;
            }

            var pawnRenderNode_Head = pawn.Drawer.renderer.renderTree.rootNode?.children
                .OfType<PawnRenderNode_Head>()
                .FirstOrDefault(x => x?.Props?.tagDef == bedAnimationSetting.parentBedAnimationDef.pawnRenderNodeTagDef);

            if (pawnRenderNode_Head == null)
            {
                return null;
            }

            if (pawn.Drawer.renderer.CurRotDrawMode == RotDrawMode.Dessicated)
            {
                return HeadTypeDefOf.Skull.GetGraphic(pawn, Color.white);
            }

            var graphicData = bedAnimationSetting.graphicData;
            var skinShader = graphicData.shaderType?.Shader ?? ShaderDatabase.Cutout;
            var color = graphicData.color;

            if (bedAnimationSetting.setPawnColor)
            {
                color = pawnRenderNode_Head.ColorFor(pawn);
                skinShader = ShaderUtility.GetSkinShader(pawn);
            }

            return GraphicDatabase.Get<Graphic_Multi>(graphicData.texPath, skinShader, graphicData.drawSize * 1.25f, color);
        }

        public static Graphic GraphicForBody(Pawn pawn, BedAnimationSetting bedAnimationSetting)
        {
            var pawnRenderNode_Body = pawn.Drawer.renderer.renderTree.rootNode?.children
                .OfType<PawnRenderNode_Body>()
                .FirstOrDefault(child => child?.Props?.tagDef == bedAnimationSetting.parentBedAnimationDef.pawnRenderNodeTagDef);

            if (pawnRenderNode_Body == null)
            {
                return null;
            }

            var shader = bedAnimationSetting.graphicData.shaderType?.Shader ?? ShaderDatabase.Cutout;

            if (pawn.Drawer.renderer.CurRotDrawMode == RotDrawMode.Dessicated)
            {
                return GraphicDatabase.Get<Graphic_Multi>(pawn.story.bodyType.bodyDessicatedGraphicPath, shader);
            }

            var color = bedAnimationSetting.graphicData.color;
            if (bedAnimationSetting.setPawnColor)
            {
                color = pawnRenderNode_Body.ColorFor(pawn);
                shader = pawnRenderNode_Body.ShaderFor(pawn);
            }

            return GraphicDatabase.Get<Graphic_Multi>(bedAnimationSetting.graphicData.texPath, shader, bedAnimationSetting.graphicData.drawSize * 1.25f, color);
        }

        public static void SetAnimation(Building_AnimationBed building_AnimationBed)
        {
            Pawn heldPawn = building_AnimationBed.HeldPawn;
            var animationSettingComp = building_AnimationBed.AnimationSettingComp;

            if (!MakeBedAnimation(building_AnimationBed))
            {
                return;
            }

            foreach (var bedAnimationSettingAndTick in animationSettingComp.bedAnimationSettingAndTicks)
            {
                if (building_AnimationBed.setAnimation)
                {
                    bedAnimationSettingAndTick.currentTick = 0;
                }
                else if (bedAnimationSettingAndTick.parentBedAnimationDef.autoDurationTicksSetting)
                {
                    bedAnimationSettingAndTick.currentTick = heldPawn.Drawer.renderer.renderTree.AnimationTick;
                }
                else
                {
                    bedAnimationSettingAndTick.currentTick =
                        bedAnimationSettingAndTick.currentTick < bedAnimationSettingAndTick.durationTick - 1
                        ? bedAnimationSettingAndTick.currentTick + 1 : 0;
                }

                if (bedAnimationSettingAndTick.parentBedAnimationDef.logCurrentTick)
                {
                    TestLog.Error($"{bedAnimationSettingAndTick.parentBedAnimationDef} : " + bedAnimationSettingAndTick.currentTick + $"(current texture : {bedAnimationSettingAndTick.durationTick})");
                }
            }

            building_AnimationBed.setAnimation = false;
        }
    }
}
